package compilador;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.HeadlessException;
import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.StringSelection;
import java.awt.datatransfer.UnsupportedFlavorException;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;

import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JButton;
import javax.swing.JEditorPane;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTextField;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.ScrollPaneConstants;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.text.BadLocationException;

import compilador.codigosLexicoGals.LexicalError;
import compilador.codigosLexicoGals.Lexico;
import compilador.codigosLexicoGals.SemanticError;
import compilador.codigosLexicoGals.Semantico;
import compilador.codigosLexicoGals.Sintatico;
import compilador.codigosLexicoGals.SyntaticError;

import javax.swing.JTextArea;

/*
 * Author do código: Luan L. Guarnieri
 * 
 * Dúvidas em processo do codigo estou a disposição para explicar,
 * pois tive que montrar umas gambiarras em algumas partes kkkk ;)
 * */

public class Interface {

	private JFrame frame;
	private JTextField tfStatus;
	private AddIcones addImg = new AddIcones();

	private JEditorPane editorMsg;
	private JTextArea editor;
	private boolean arquivoAberto = false;
	private String caminho ="   Pasta \\ Arquivo";
	
	public static void main(String[] args) {
		Interface window = new Interface();
		window.frame.setVisible(true);
	}

	public Interface() {
		initialize();
	}

	private void initialize() {
		frame = new JFrame();
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setBounds(100, 100, 940, 640);
		frame.setMinimumSize(new Dimension(910, 600));
		frame.setTitle("COMPILADOR 2022.2");
		editorMsg = new JEditorPane();
		editorMsg.setEditable(false);

		JPanel panel = new JPanel();

		GroupLayout groupLayout = new GroupLayout(frame.getContentPane());
		groupLayout.setHorizontalGroup(groupLayout.createParallelGroup(Alignment.LEADING).addComponent(panel,
				GroupLayout.DEFAULT_SIZE, 924, Short.MAX_VALUE));
		groupLayout.setVerticalGroup(groupLayout.createParallelGroup(Alignment.TRAILING).addComponent(panel,
				Alignment.LEADING, GroupLayout.DEFAULT_SIZE, 601, Short.MAX_VALUE));

		tfStatus = new JTextField();
		tfStatus.setColumns(10);
		tfStatus.setBorder(null);
		tfStatus.setEditable(false);
		tfStatus.setBackground(new Color(212, 212, 212));
		tfStatus.setSize(new Dimension(900, 25));
		tfStatus.setText(caminho);

		JPanel panelMenu = new JPanel(new GridLayout(1, 8, 4, 0));
		panelMenu.setBorder(null);
		panelMenu.setSize(new Dimension(960, 70));

		JButton btnNovo = new JButton("Novo [ctrl+N]");
		addImg.addImagem(btnNovo, "Icones/novo.png");
		panelMenu.add(btnNovo);
		btnNovo.addActionListener(e -> {

			confirmarAcao();
		});

		JButton btnAbrir = new JButton("Abrir [ctrl+O]");
		addImg.addImagem(btnAbrir, "Icones/abrir.png");
		panelMenu.add(btnAbrir);
		btnAbrir.addActionListener(e -> {
			abrir();
		});

		JButton btnSalvar = new JButton("Salvar [ctrl+S]");
		addImg.addImagem(btnSalvar, "Icones/salvar.png");
		panelMenu.add(btnSalvar);
		btnSalvar.addActionListener(e -> {
			salvar();
		});

		JButton btnCopiar = new JButton("Copiar [ctrl+C]");
		addImg.addImagem(btnCopiar, "Icones/copiar.png");
		panelMenu.add(btnCopiar);
		btnCopiar.addActionListener(e -> {
			copiar();
		});

		JButton btnColar = new JButton("Colar [ctrl+V]");
		addImg.addImagem(btnColar, "Icones/colar.png");
		panelMenu.add(btnColar);
		btnColar.addActionListener(e -> {
			try {
				colar();
			} catch (BadLocationException e1) {
				e1.printStackTrace();
			}
		});

		JButton btnRecortar = new JButton("Recortar [ctrl+X]");
		addImg.addImagem(btnRecortar, "Icones/recortar.png");
		panelMenu.add(btnRecortar);
		btnRecortar.addActionListener(e -> {
			recortar();
		});

		JButton btnCompilar = new JButton("Compilar [F7]");
		addImg.addImagem(btnCompilar, "Icones/compilar.png");
		panelMenu.add(btnCompilar);
		btnCompilar.addActionListener(e -> {
			compilar();
		});

		JButton btnEquipe = new JButton("Equipe [F1]");
		addImg.addImagem(btnEquipe, "Icones/equipe.png");
		panelMenu.add(btnEquipe);
		btnEquipe.addActionListener(e -> equipe());

		JSplitPane splitPane = new JSplitPane();
		JPanel panelEditor = new JPanel();
		JPanel panelMensagem = new JPanel();
		JScrollPane scpEditor = new JScrollPane();
		JScrollPane scpMsg = new JScrollPane();

		splitPane.setDividerLocation(330);
		splitPane.setBorder(null);
		panelEditor.setBorder(null);
		panelMensagem.setBorder(null);
		scpMsg.setBorder(null);
		scpEditor.setBorder(null);

		GroupLayout gl_panelEditor = new GroupLayout(panelEditor);
		GroupLayout gl_panelMensagem = new GroupLayout(panelMensagem);
		scpEditor.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
		splitPane.setOrientation(JSplitPane.VERTICAL_SPLIT);
		splitPane.setLeftComponent(panelEditor);
		splitPane.setRightComponent(panelMensagem);
		scpEditor.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS);
		scpMsg.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS);
		scpMsg.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);

		gl_panelEditor.setHorizontalGroup(gl_panelEditor.createParallelGroup(Alignment.LEADING).addComponent(scpEditor,
				GroupLayout.DEFAULT_SIZE, 390, Short.MAX_VALUE));
		gl_panelEditor.setVerticalGroup(gl_panelEditor.createParallelGroup(Alignment.LEADING).addComponent(scpEditor,
				Alignment.TRAILING, GroupLayout.DEFAULT_SIZE, 151, Short.MAX_VALUE));

		editor = new JTextArea();
		editor.setBorder(new NumberedBorder());
		scpEditor.setViewportView(editor);
		panelEditor.setLayout(gl_panelEditor);

		gl_panelMensagem.setHorizontalGroup(gl_panelMensagem.createParallelGroup(Alignment.LEADING).addComponent(scpMsg,
				Alignment.TRAILING, GroupLayout.DEFAULT_SIZE, 309, Short.MAX_VALUE));
		gl_panelMensagem.setVerticalGroup(gl_panelMensagem.createParallelGroup(Alignment.LEADING).addComponent(scpMsg,
				Alignment.TRAILING, GroupLayout.DEFAULT_SIZE, 151, Short.MAX_VALUE));

		scpMsg.setViewportView(editorMsg);
		panelMensagem.setLayout(gl_panelMensagem);
		GroupLayout gl_panel = new GroupLayout(panel);
		gl_panel.setHorizontalGroup(gl_panel.createParallelGroup(Alignment.TRAILING)
				.addComponent(tfStatus, GroupLayout.DEFAULT_SIZE, 924, Short.MAX_VALUE)
				.addComponent(splitPane, GroupLayout.DEFAULT_SIZE, 924, Short.MAX_VALUE).addGroup(Alignment.LEADING,
						gl_panel.createSequentialGroup().addContainerGap()
								.addComponent(panelMenu, GroupLayout.PREFERRED_SIZE, 778, GroupLayout.PREFERRED_SIZE)
								.addContainerGap(136, Short.MAX_VALUE)));
		gl_panel.setVerticalGroup(gl_panel.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel.createSequentialGroup()
						.addComponent(panelMenu, GroupLayout.PREFERRED_SIZE, 70, GroupLayout.PREFERRED_SIZE).addGap(29)
						.addComponent(splitPane, GroupLayout.DEFAULT_SIZE, 474, Short.MAX_VALUE)
						.addPreferredGap(ComponentPlacement.RELATED)
						.addComponent(tfStatus, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE)));
		panel.setLayout(gl_panel);
		frame.getContentPane().setLayout(groupLayout);

		// acoes dos botoes

		editor.addKeyListener(new KeyListener() {

			public void keyTyped(KeyEvent e) {
			}

			public void keyReleased(KeyEvent e) {
			}

			public void keyPressed(KeyEvent e) { // quando as teclas estiverem precionadas

				if (e.isControlDown() && e.getKeyCode() == 78) {// novo
					confirmarAcao();
				}

				if (e.isControlDown() && e.getKeyCode() == 79) { // abrir
					abrir();
				}

				if (e.isControlDown() && e.getKeyCode() == 83) { // abrir
					salvar();
				}

				if (e.isControlDown() && e.getKeyCode() == 99) { // copiar
					copiar();
				}

				if (e.isControlDown() && e.getKeyCode() == 118) { // colar
					try {
						colar();
					} catch (BadLocationException e1) {
						e1.printStackTrace();
					}
				}

				if (e.isControlDown() && e.getKeyCode() == 88) { // recortat
					recortar();
				}

				if (e.getKeyCode() == 118) { // compilar
					compilar();
				}

				if (e.getKeyCode() == 112) { // equipe
					equipe();
				}
			}
		});
	}

	private void novo() {
		editor.setText(null);
		editorMsg.setText(null);
		caminho = "   Pasta \\ Arquivo";
		tfStatus.setText(caminho);
	}

	private void abrir() {
		FileNameExtensionFilter filtro = new FileNameExtensionFilter("Escolha penas .txt", "txt"); // mudar futuramente
		JFileChooser fc = new JFileChooser();
		fc.setDialogTitle("Abrir arquivo");
		fc.addChoosableFileFilter(filtro);
		fc.setAcceptAllFileFilterUsed(false); // aceitando apenas arquivos txxt
		int retorno = fc.showOpenDialog(editor);

		if (retorno == JFileChooser.APPROVE_OPTION) {
			File arquivo = fc.getSelectedFile();
			caminho = arquivo.getAbsolutePath();
			String linha = new String();
			String texto = "";

			try {
				FileReader leitor = new FileReader(arquivo);
				BufferedReader buffer = new BufferedReader(leitor);

				while (true) {
					linha = buffer.readLine();

					if (linha == null) {
						break;
					}
					
					texto += linha + "\n";
				}
				arquivoAberto = true;
				editor.setText(texto);
				buffer.close();
				tfStatus.setText(caminho);
			} catch (FileNotFoundException e) {
				editorMsg.setText("Erro ao ler o arquivo");
			} catch (IOException e) {

				System.out.println("Se chegar aqui nem sei oq causou");
			}
		} else {
			editorMsg.setText("Arquivo inválido");
		}
	}

	private void salvar() {
		
		File arq = new File(caminho);

		if (arq.exists()) {
			gravar(arq);
		} else {
			
			JFileChooser fc = new JFileChooser();
			fc.setDialogTitle("Salvar arquivo");
			int i = fc.showSaveDialog(frame);

			if (i == JFileChooser.APPROVE_OPTION) {
				arq = new File(fc.getSelectedFile().getAbsolutePath());
				gravar(arq);
			}
		}

	}

	private void copiar() {
		Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
		StringSelection selection = new StringSelection(editor.getSelectedText());
		clipboard.setContents(selection, selection);

	}

	private void colar() throws BadLocationException {
		try {
			String g = (String) Toolkit.getDefaultToolkit().getSystemClipboard().getData(DataFlavor.stringFlavor);

			int posicao = editor.getCaretPosition();

			editor.getDocument().insertString(posicao, g, null);

		} catch (HeadlessException | UnsupportedFlavorException | IOException e1) {
			JOptionPane.showMessageDialog(editor, "Não é possivel colar o conteúdo da area de tranferencia");
			e1.printStackTrace();
		}

	}

	private void recortar() {
		copiar();
		String aux = editor.getSelectedText();
		editor.setText(editor.getText().replaceAll(aux, ""));
	}

	private void compilar() {
		if (editor.getText().length() < 1) {
			JOptionPane.showMessageDialog(frame, "Não possui codigo na area de texto");
		} else {

			Lexico lexico = new Lexico();
			Sintatico sintatico = new Sintatico();
			Semantico semantico = new Semantico();

			lexico.setInput(editor.getText());

			try {
				sintatico.parse(lexico, semantico);
				editorMsg.setText("Programa compilado com sucesso!");
			} catch (LexicalError e) {
				String error = "Erro na linha " + e.getLinha() + " - " + erroLexico(e.getMessage(), e.getPosition())
						+ " " + e.getMessage();

				editorMsg.setText(error);
			} catch (SyntaticError e) {
				editorMsg.setText("Erro na linha " + e.getLinha() + " - " + " encontrado  " + e.getPalavra() + " "
						+ e.getMessage());
			} catch (SemanticError e) {
				// Trata erros semânticos
			}

		}

	}

	private void equipe() {
		editorMsg.setText("\t== Alunos: ==\nLuan L. Guarnieri , Claudio R. Da Silva , Gabriel Mori");
	}

	private void gravar(File file) {
		PrintWriter gravar = null;

		try {
			gravar = new PrintWriter(file);
			gravar.println(editor.getText());

		} catch (FileNotFoundException e1) {
			JOptionPane.showInternalMessageDialog(frame, "ERRO AO GRAVAR ARQUIVO");

		} finally {
			gravar.close();

		}
	}

	private String erroLexico(String mensagem, int posicao) {

		if (mensagem.equals("Simbolo inválido")) {
			return "' " + editor.getText().charAt(posicao - 1) + " '"; // retornando o caractere
		}

		if (mensagem.equals("Comentário de bloco inválido ou não finalizado")) {
			return "' [ '"; 
		
		} else return " ";
	}
	
	private void confirmarAcao() {
		if (tfStatus.getText().equals("   Pasta \\ Arquivo")) {
			arquivoAberto = false;
		} else {
			arquivoAberto = true;
		}

		if (arquivoAberto) {
			int i = JOptionPane.showConfirmDialog(frame, "Deseja abrir um novo arquivo sem salvar o atual?");
			if (i == 0) {
				novo();
			} else if (i == 1) {
				salvar();
				novo();
				JOptionPane.showMessageDialog(editor, "Arquivo Salvo");
			}
		} else {
			String aux = editor.getText();
			if (aux.equals("")) {
				novo();
			} else {
				int i = JOptionPane.showConfirmDialog(frame, "Arquivo atual não foi salvo, descartar?");
				if (i == 0) {
					novo();
				} else if (i == 1) {
					salvar();
				}
			}
		}
	}
}
