package compilador.codigosLexicoGals;

public class SemanticError extends AnalysisError
{
    public SemanticError(String msg, int position)
	 {
        super(msg, position, position);
    }

    public SemanticError(String msg)
    {
        super(msg);
    }
}
