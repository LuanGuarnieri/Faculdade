package compilador.codigosLexicoGals;

public class SyntaticError extends AnalysisError
{
	private String palavra;
    public SyntaticError(String msg, int position, int linha, String lexeme)
	 {
        super(msg, position, linha);
        this.palavra = lexeme;
    }

    public SyntaticError(String msg)
    {
        super(msg);
    }
    
    public String getPalavra() {
    	return this.palavra;
    }
}
