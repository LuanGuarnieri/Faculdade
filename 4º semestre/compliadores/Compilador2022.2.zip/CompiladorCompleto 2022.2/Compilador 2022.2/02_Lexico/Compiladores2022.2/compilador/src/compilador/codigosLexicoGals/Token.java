package compilador.codigosLexicoGals;

public class Token
{
    private int id;
    private String lexeme;
    private int position;
    private int linha;

    public Token(int id, String lexeme, int position, int linha)
    {
        this.id = id;
        this.lexeme = lexeme;
        this.position = position;
        this.linha = linha;
    }

    public final int getId()
    {
        return id;
    }

    public final String getLexeme()
    {
        return lexeme;
    }

    public final int getPosition()
    {
        return position;
    }

    public String toString()
    {
        return id+" ( "+lexeme+" ) @ "+position;
    };
    
    public int getLinha()
    {
    	return this.linha;
    }
    
    public String getClasse()
    {
    	if(id == 2) {return "Identificador";}
    	
    	if(id == 3) {return "Const. int";}
    	
    	if(id == 4) {return "Const. float";}
    	
    	if(id == 5) {return "Const.char";}
    	
    	if(id == 6) {return "Cons. String";}
    	
    	if(id > 6 && id <=26) {return "P. reservada"; }
    	
    	else {
    		return "Carac. especial";
    	}
    }
}
