package compilador;

import java.awt.Color;
import java.awt.Font;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.SwingConstants;

public class AddIcones {
	public void addImagem(JButton b,String n) { // adicionando as imagem nos botoes
		ImageIcon img = new ImageIcon(getClass().getResource(n));
		
		b.setIcon(img);
		b.setVerticalTextPosition(SwingConstants.BOTTOM);
		b.setHorizontalTextPosition(SwingConstants.CENTER);
		b.setFont(new Font("Calibri", Font.BOLD, 11));
		b.setBackground(new Color(217, 217, 217));
		b.setBorder(null);
	}

}
