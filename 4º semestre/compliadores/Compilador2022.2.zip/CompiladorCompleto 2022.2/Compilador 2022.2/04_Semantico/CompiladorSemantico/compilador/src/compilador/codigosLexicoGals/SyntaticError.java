package compilador.codigosLexicoGals;

public class SyntaticError extends AnalysisError
{
	private String palavra;
    public SyntaticError(String msg, int linha, String lexeme)
	 {
        super(msg, linha);
        this.palavra = lexeme;
    }

    public SyntaticError(String msg)
    {
        super(msg);
    }
    
    public String getPalavra() {
    	return this.palavra;
    }
}
