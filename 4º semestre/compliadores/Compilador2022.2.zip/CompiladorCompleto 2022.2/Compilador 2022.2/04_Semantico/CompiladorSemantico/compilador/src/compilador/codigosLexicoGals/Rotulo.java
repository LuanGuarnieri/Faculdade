package compilador.codigosLexicoGals;

public class Rotulo {
	private int rotulo;
	
	public Rotulo(int num) {
		this.rotulo = num;
	}
	
	public int getRotulo() {
		return this.rotulo;
	}
}
