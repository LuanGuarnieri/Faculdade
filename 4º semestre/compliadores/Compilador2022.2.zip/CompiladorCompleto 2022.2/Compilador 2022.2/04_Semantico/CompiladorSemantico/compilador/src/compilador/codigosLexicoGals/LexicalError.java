package compilador.codigosLexicoGals;

public class LexicalError extends AnalysisError
{
    public LexicalError(String msg,int linha)
	 {
        super(msg, linha);
    }

    public LexicalError(String msg)
    {
        super(msg);
    }
}
