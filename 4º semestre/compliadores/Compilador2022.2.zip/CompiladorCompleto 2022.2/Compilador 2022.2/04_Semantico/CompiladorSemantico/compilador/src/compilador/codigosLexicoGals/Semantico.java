package compilador.codigosLexicoGals;
/*
 * Authordo código: Luan L. Guarnieri - BCC FURB 2022.2 
 * */
import java.io.File;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Stack;

import compilador.Interface;

public class Semantico implements Constants {
	// private Stack<String> pilha = new Stack<String>(); // pilha
	private HashMap<String, String> ts = new HashMap<>(); // chave simbolos - valores identificadores
	private Stack<Rotulo> pilhaRotulos = new Stack<Rotulo>(); // pilha de rotulos
	private Stack<String> pilhaTipos = new Stack<>(); // pilha de tipos
	private Stack<String> tipo_var = new Stack<>(); // armazenar o tipo (acao 30)
	private List<String> listaId = new ArrayList<>(); // lista de ids

	private String tipo1, tipo2, operador = "", token = "";
	private int linha = 0;
	FileWriter esc;
	File arq;

	public Semantico(Interface f) {

		if (f.getCaminho().equals("   Pasta \\ Arquivo")) {
			f.salvar();
		}

		arq = new File(f.getCaminho().replace(".txt", ".il"));// criando o arquivo no mesmo caminho;
	}

	public void executeAction(int action, Token token) throws SemanticError {

		if (token == null || token.getLexeme() == null) { // essas validaçoes coloquei apenas para não gerar
															// nullxception na primeira chamada
			this.token = "vazio";
			this.linha = -1;
		} else {
			this.token = token.getLexeme();
			this.linha = token.getLinha();
		}

		//System.out.println("acao: " + action + "  valor do lexeme: " + this.token + " na linha: " + this.linha);

			switch (action) {
			case 1:
				acao1();
				break;

			case 2:
				acao2();
				break;

			case 3:
				acao3();
				break;

			case 4:
				acao4();
				break;

			case 5:
				acao5();
				break;

			case 6:
				acao6();
				break;

			case 7:
				acao7();
				break;

			case 8:
				acao8();
				break;

			case 9:
				acao9();
				break;

			case 10:
				acao10();
				break;

			case 11:
				acao11();
				break;

			case 12:
				acao12();
				break;

			case 13:
				acao13();
				break;

			case 14:
				acao14();
				break;

			case 15:
				acao15();
				break;

			case 16:
				acao16();
				break;

			case 17:
				acao17();
				break;

			case 18:
				acao18();
				break;

			case 19:
				acao19();
				break;

			case 20:
				acao20();
				break;

			case 21:
				acao21();
				break;

			case 22:
				acao22();
				break;

			case 24:
				acao24();
				break;

			case 25:
				acao25();
				break;

			case 26:
				acao26();
				break;

			case 27:
				acao27();
				break;

			case 28:
				acao28();
				break;

			case 30:
				acao30();
				break;

			case 31:
				acao31();
				break;

			case 32:
				acao32();
				break;

			case 33:
				acao33();
				break;

			case 34:
				acao34();
				break;

			case 35:
				acao35();
				break;
			}
		// System.out.println("Ação #"+action+", Token: "+token);
	}

	// AÇÕES A FAZER

	private void acao1() throws SemanticError {

		tipo1 = pilhaTipos.pop();
		tipo2 = pilhaTipos.pop();

		if (tipo1.charAt(0) != 'f' || tipo1.charAt(0) != 'i' || tipo2.charAt(0) != 'f' || tipo2.charAt(0) != 'i') {
			retornaErro(token, linha, 1);
			return;
		}

		if (tipo1.equals("float64") || tipo2.equals("float64")) {
			pilhaTipos.push("float64");

		} else {
			pilhaTipos.push("int64");
		}
		escrever("add\n", true);
	}

	private void acao2() throws SemanticError {

		tipo1 = pilhaTipos.pop();
		tipo2 = pilhaTipos.pop();

		if (tipo1.charAt(0) != 'f' || tipo1.charAt(0) != 'i' || tipo2.charAt(0) != 'f' || tipo2.charAt(0) != 'i') {
			retornaErro(token, linha, 1);
			return;
		}

		if (tipo1.equals("float64") || tipo2.equals("float64")) {
			pilhaTipos.push("float64");

		} else {
			pilhaTipos.push("int64");
		}
		escrever("sub\n", true);
	}

	private void acao3() throws SemanticError {

		tipo1 = pilhaTipos.pop();
		tipo2 = pilhaTipos.pop();

		if (tipo1.contains("b") || tipo1.contains("s") || tipo2.contains("b") || tipo2.contains("s")) {
			System.out.println("tipo1 = " + tipo1 + " / tipo2 = " + tipo2);
			retornaErro(token, linha, 1);
			return;
		}

		if (tipo1.equals("float64") || tipo2.equals("float64")) {
			pilhaTipos.push("float64");

		} else {
			pilhaTipos.push("int64");
		}

		escrever("mul\n", true);
	}

	private void acao4() throws SemanticError {

		tipo1 = pilhaTipos.pop();
		tipo2 = pilhaTipos.pop();

		if (tipo1.charAt(0) != 'f' || tipo1.charAt(0) != 'i' || tipo2.charAt(0) != 'f' || tipo2.charAt(0) != 'i') {
			retornaErro(token, linha, 1);
			return;
		}

		if (tipo1.equals("float64") || tipo2.equals("float64")) {
			pilhaTipos.push("float64");

		} else {
			pilhaTipos.push("int64");
		}

		escrever("div\n", true);
	}

	private void acao5() throws SemanticError {
		String[] aux = new String[2];
		int num;
		pilhaTipos.push("int64");

		if (token.contains("d")) {
			aux = token.split("d");
			num = (int) (Integer.parseInt(aux[0]) * (Math.pow(10, Integer.parseInt(aux[1]))));

		} else {
			num = Integer.parseInt(token);
		}

		aux[0] = "ldc.i8 " + num + "\n" + "conv.r8\n"; // apenas reutilizando a variavel
		escrever(aux[0], true);
	}

	private void acao6() throws SemanticError {
		String[] aux = new String[2];
		float num;
		pilhaTipos.push("float64");

		if (token.charAt(0) == '.') {
			token = "0" + token;
		}

		if (token.contains("d")) {
			aux = token.split("d");
			num = (float) (Float.parseFloat(aux[0]) * (Math.pow(10, Float.parseFloat(aux[1]))));

		} else {
			num = Float.parseFloat(token);
		}

		escrever("ldc.r8 " + num + "\n", true);
	}

	private void acao7() throws SemanticError {

		tipo1 = pilhaTipos.pop();

		if (tipo1.equals("float64") || tipo1.equals("int64")) {
			pilhaTipos.push(tipo1);

		} else {
			retornaErro(token, linha, 7);
		}
	}

	private void acao8() throws SemanticError {

		tipo1 = pilhaTipos.pop();
		String aux = "ldc.i8 -1\n" + "conv.r8\n" + "sub\n";
		if (tipo1.equals("float64") || tipo1.equals("int64")) {
			pilhaTipos.push(tipo1);

			escrever(aux, true);

		} else {
			retornaErro(token, linha, 8);
		}
	}

	private void acao9() {
		operador = token;
	}

	private void acao10() throws SemanticError {

		tipo1 = pilhaTipos.pop();
		tipo2 = pilhaTipos.pop();

		if (tipo1.equals(tipo2)) {
			pilhaTipos.push("bool");

		} else {
			retornaErro(token, linha, 10);
			return;
		}

		if (tipo1.equals("string")) {
			escrever("call int32 [mscorlib]System.String::Compare(string, string)\n", true); // vai comparar as string

		} else {

			switch (operador) {

			case "!=":
				escrever("ceq" + "\n" + "ldc.i4.0" + "\n" + "ceq\n", true); // negando a igualdade para gerar demonstrar
																			// a diferença
				break;

			case ">":
				escrever("cgt\n", true);
				break;

			case "<":
				escrever("clt\n", true);
				break;

			case "==":
				escrever("ceq\n", true);
				break;
			}
		}
	}

	private void acao11() throws SemanticError {

		pilhaTipos.push("bool");
		escrever("ldc.i4.1\n", true);
	}

	private void acao12() throws SemanticError {

		pilhaTipos.push("bool");
		escrever("ldc.i4.0\n", true);
	}

	private void acao13() throws SemanticError {

		tipo1 = pilhaTipos.pop();

		if (tipo1.equals("bool")) {
			pilhaTipos.push("bool");
			escrever("not\n", true);

		} else {
			retornaErro(token, linha, 13);
		}
	}

	private void acao14() throws SemanticError {

		tipo1 = pilhaTipos.pop();

		if (tipo1.equals("int64")) {
			escrever("conv.i8\n", true);
		}
		escrever("call void [mscorlib] System.Console::Write(" + tipo1 + ")\n", true);
	}

	private void acao15() throws SemanticError {
		String str = ".assembly extern mscorlib {}" + "\n" + ".assembly _codigo_objeto{}\n"
				+ ".module   _codigo_objeto.exe\n\n" + ".class public _UNICA{\n\n"
				+ ".method static public void _principal() {\n" + ".entrypoint\n";

		escrever(str, false);
	}

	private void acao16() throws SemanticError {
		String str = "ret\n" + "}\n" + "}";

		escrever(str, true);
	}

	private void acao17() throws SemanticError {

		String tipo = pilhaTipos.pop();

		if (tipo.equals("int64")) {
			escrever("conv.i8\n", true);
		}
		escrever("call void [mscorlib]System.Console::Write(" + tipo + ")\n", true);
	}

	private void acao18() throws SemanticError {
		tipo1 = pilhaTipos.pop();
		tipo2 = pilhaTipos.pop();

		if (tipo1.equals("bool") && tipo2.equals("bool")) {
			pilhaTipos.push("bool");
			escrever("and\n", true);
		} else {
			retornaErro(token, linha, 18);
		}
	}

	private void acao19() throws SemanticError {
		tipo1 = pilhaTipos.pop();
		tipo2 = pilhaTipos.pop();

		if (tipo1.equals("bool") && tipo2.equals("bool")) {
			pilhaTipos.push("bool");
			escrever("or\n", true);
		} else {
			retornaErro(token, linha, 19);
		}
	}

	private void acao20() {
		// resto da divisão (%) não achei como representar em MSIL
		System.out.println("ação 20");
	}

	private void acao21() throws SemanticError {

		acao22(); // para char, usa o mesmo que string
	}

	private void acao22() throws SemanticError {
		pilhaTipos.push("string");
		escrever("ldstr " + token + "\n", true);
	}

	private void acao24() throws SemanticError {
		Rotulo r = new Rotulo(pilhaRotulos.size() + 1);
		String aux = "brfalse L" + r.getRotulo() + "\n";

		escrever(aux, true);
		pilhaRotulos.push(r);
	}

	private void acao25() throws SemanticError {
		Rotulo r = new Rotulo(pilhaRotulos.size() + 1);

		escrever("br L" + r.getRotulo() + "\n", true);
		escrever("L" + pilhaRotulos.pop().getRotulo() + ":\n", true);

		pilhaRotulos.push(r);
	}

	private void acao26() throws SemanticError {
		escrever("L" + pilhaRotulos.pop().getRotulo() + ":\n", true);
		System.out.println("ação 26");
	}

	private void acao27() throws SemanticError {
		Rotulo r = new Rotulo(pilhaRotulos.size() + 1);
		pilhaRotulos.push(r);
		escrever("L" + r.getRotulo() + ":\n", true);
	}

	private void acao28() throws SemanticError {
		Rotulo r = pilhaRotulos.pop(); // desempilhando
		escrever("brtrue L" + r.getRotulo() + "\n", true);
	}

	private void acao30() {

		if (token.equals("int")) {
			tipo_var.push("int64");

		} else if (token.equals("float")) {
			tipo_var.push("float64");

		} else if (token.equals("string")) {
			tipo_var.push("string");

		} else if (token.equals("char")) {
			tipo_var.push("char");

		} else if (token.equals("boolean")) {
			tipo_var.push("bool");
		}
	}

	private void acao31() throws SemanticError {
		String aux = "";

		for (String id : listaId) {

			if (ts.get(id) != null) {
				throw new SemanticError("Erro na ação 31 - id: " + id + " encontrado na pilha TS");
			}

			aux = tipo_var.pop();

			if (aux.equals("char")) {
				aux = "string";
			}
			ts.put(id, aux);
			escrever(".locals(" + aux + " " + id + ")\n", true);
		}
		listaId.clear();
	}

	private void acao32() {
		listaId.add(token);
	}

	private void acao33() throws SemanticError {

		String tipoId = ts.get(token);

		/*
		 * if ( tipoId == null ) { throw new SemanticError("token " + token +
		 * " não encontrado no map de simbolos (TS)" ); }
		 */
		escrever("ldloc " + token + "\n", true);
		pilhaTipos.push(tipoId);

		if (tipoId.equals("int64")) {
			escrever("conv.r8\n", true);
		}
	}

	private void acao34() throws SemanticError {
		String id = listaId.get(0), tipoId = "";

		tipoId = ts.get(id);
		pilhaTipos.pop();

		if (tipoId.equals("int64")) {
			escrever("conv.i8\n", true);
		}
		escrever("stloc " + id + "\n", true);
	}

	private void acao35() throws SemanticError {
		String tipoId = "", classe = "";

		for (String id : listaId) {

			tipoId = ts.get(id);

			switch (tipoId) {
			case "int64":
				classe = "Int64";
				break;

			case "float64":
				classe = "Double";
				break;

			case "bool":
				classe = "Boolean";
				break;
			}

			escrever("call string [mscorlib] System.Console::ReadLine()\n", true);

			if (!tipoId.equals("string")) {
				escrever("call " + tipoId + " [mscorlib] System." + classe + "::Parse(string)\n", true);
			}

			escrever("stloc " + id + "\n", true);

		}
		listaId.clear();
	}

	private void retornaErro(String token, int linha, int acao) throws SemanticError {

		if (acao == 10) {
			throw new SemanticError("tipos incompativeis em expressao relacional", token, linha);
		}

		if (acao == 1 || acao == 2 || acao == 3 || acao == 4 || acao == 7 || acao == 8 || acao == 20) {
			throw new SemanticError("tipo(s) incompatível(is) em expressão aritmética", token, linha);
		}

		if (acao == 13 || acao == 18 || acao == 19) {
			throw new SemanticError("tipo(s) incompatível(is) em expressão lógica", token, linha);
		}
	}

	private void escrever(String txt, boolean opcao) throws SemanticError {
		try {

			esc = new FileWriter(arq, opcao);
			esc.write(txt);
			esc.close();

		} catch (Exception e) {
			throw new SemanticError("Erro ao abrir o arquivo" + "\n");
		}
	}
}
