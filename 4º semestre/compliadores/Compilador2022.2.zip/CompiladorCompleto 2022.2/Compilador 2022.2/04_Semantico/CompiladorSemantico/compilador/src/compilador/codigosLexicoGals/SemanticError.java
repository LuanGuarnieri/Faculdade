package compilador.codigosLexicoGals;

public class SemanticError extends AnalysisError
{
	String msg, token;
	int linha;
	
    public SemanticError(String msg,String token, int linha)
	 {
        super(msg, linha);
        this.msg = msg;
        this.token = token;
        this.linha =  linha;
    }
    
    public SemanticError(String msg) {
    	super(msg);
    }

    public String getMensagem() {
    	return msg + " na linha " + linha + " no token " + token;
    }
}


