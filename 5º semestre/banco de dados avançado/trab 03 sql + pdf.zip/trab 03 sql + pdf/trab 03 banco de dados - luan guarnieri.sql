/*
a) manter um log com todas as operações DML (insert, update e delete) realizadas na tabela cliente. Dica, criar uma
 tabela e registrar os eventos (logs) com: data, hora, operação realizada e usuário. Utilize o usuário logado na 
 seção (função user()) para saber o usuário que executou a operação. Importante: nos casos 
que envolve alterações (update), registrar no logo o valor antigo e o novo valor (alterado); 
*/

-- criando a tabela de registros - llguarnieri
create table log_tab_cliente
(
	id_registro mediumint not null auto_increment,
	cliente_cd  int(11) not null,
	tp_operacao varchar(10) not null,
	ds_operacao varchar(100) not null,
	nm_usuario varchar(50) not null,
	dt_operacao datetime not null,
	
	primary key(id_registro)
);

-- trigger para disparar após o insert - llguarnieri
create or replace trigger tg_insert_clientes before insert 
on cliente for each row

begin
	
	insert into log_tab_cliente ( cliente_cd, tp_operacao, 
								  ds_operacao, 
								  nm_usuario, 
								  dt_operacao )
	values ( (select max(cd_cliente) from cliente),
			 "INSERT",
			 "INSERINDO NOVO CLIENTE",
			 user(),
			 convert( concat( curdate()," ", curtime()), datetime) );
end;

-- trigger para disparar após o update - llguarnieri
create or replace trigger tg_delete_clientes after update 
on cliente for each row

begin
	insert into log_tab_cliente ( cliente_cd, 
								  tp_operacao, 
								  ds_operacao, 
								  nm_usuario, 
								  dt_operacao )
	values ( old.cd_cliente,
			 "UPDATE",
			 concat("old: ",old.cd_cliente,"-",old.nm_cliente,"-",old.ds_email,"-",old.nr_telefone,
			 		" new: ",new.cd_cliente,"-",new.nm_cliente,"-",new.ds_email,"-",new.nr_telefone),
			 user(),
			 convert( concat( curdate()," ", curtime()), datetime) );
end;


-- trigger para disparar antes do delete - llguarnieri
create or replace trigger tg_delete_clientes before delete 
on cliente for each row

begin
	insert into log_tab_cliente ( cliente_cd, 
								  tp_operacao, 
								  ds_operacao, 
								  nm_usuario, 
								  dt_operacao )
	values ( old.cd_cliente,
			 "DELETE",
			 concat("CLIENTE ID: ",	old.cd_cliente," DELETADO"),
			 user(),
			 convert( concat( curdate()," ", curtime()), datetime) );
end;


-- inserindo usuario
insert into cliente (NM_CLIENTE, DS_EMAIL, NR_TELEFONE)
values ('Luan Guarnieri','llguarnieri@furb.br', '4784721588')	

-- fazendo update 
update cliente 
   set nm_cliente = 'Luan L. Guarnieri'
 where nm_cliente like '%Luan%' 

-- deletando registro
delete from cliente 
 where nm_cliente like "%Luan%" 
  
 select * from log_tab_cliente ltc 
 
 
/*
b) criar uma rotina que sinalize (liste) a disponibilidade de quarto(s), ou seja sem reserva, 
considerando uma determinada data passada com parâmetro; 
*/ 

-- mostra os quartos livres - llguarnieri
create or replace procedure pc_quartos_disponiveis(in p_data_entrada date)
begin 
	select quar.NR_QUARTO 'num quarto',
		   quar.DS_QUARTO 'descrição',
		   quar.NR_OCUPANTES 'capacidade'
	  from quarto quar
	 where not exists ( select res.NR_QUARTO
	 					  from reserva res
	 					 where res.NR_QUARTO = quar.NR_QUARTO 
	 					   and res.FL_SITUACAO like 'A'
	 					   and adddate(res.DT_RESERVA, interval res.QT_DIARIAS day) 
	 					  	   > p_data_entrada ); 
end 


-- inserindo dados teste
INSERT INTO RESERVA (DT_RESERVA, DT_ENTRADA, QT_DIARIAS, FL_SITUACAO, CD_CLIENTE, NR_QUARTO, CD_FUNCIONARIO)
VALUES ('2023-05-28', '2023-06-01', 3, 'A', 1, 101, 1);

INSERT INTO RESERVA (DT_RESERVA, DT_ENTRADA, QT_DIARIAS, FL_SITUACAO, CD_CLIENTE, NR_QUARTO, CD_FUNCIONARIO)
VALUES ('2023-05-28', '2023-06-03', 2, 'A', 2, 102, 2);

INSERT INTO RESERVA (DT_RESERVA, DT_ENTRADA, QT_DIARIAS, FL_SITUACAO, CD_CLIENTE, NR_QUARTO, CD_FUNCIONARIO)
VALUES ('2023-05-25', '2023-05-26', 1, 'A', 3, 201, 1);

INSERT INTO RESERVA (DT_RESERVA, DT_ENTRADA, QT_DIARIAS, FL_SITUACAO, CD_CLIENTE, NR_QUARTO, CD_FUNCIONARIO)
VALUES ('2023-05-27', '2023-05-28', 3, 'A', 4, 202, 2); 


-- function para gerar hospefagem - llguarnieri
create or replace function f_adiciona_hospedagem( in p_cd_cliente int,
												   in p_nr_quarto int,
												   in p_data_entrada date,
												   in p_data_saida date )											  
returns varchar(50) 
begin 
	declare v_cliente int;
	declare v_reserva int;

	-- valida se o cliente existe
	select nvl(count(1), 0)into v_cliente
	  from cliente c 
	 where c.CD_CLIENTE = p_cd_cliente; 	
	
	-- valida se já existe reserva
	select nvl(count(1), 0) into v_reserva
	  from reserva r 
	 where r.nr_quarto = 101
	   and r.fl_situacao = 'A'
	   and adddate( r.dt_entrada, interval r.qt_diarias day) >= p_data_entrada;
	
	if (v_cliente < 1) then
		return 'cliente não encontrado';
	
	elseif (v_reserva > 0) then
		return 'quarto já reservado nessa data';
	
	else
		insert into reserva (DT_RESERVA, DT_ENTRADA, QT_DIARIAS,FL_SITUACAO, CD_CLIENTE, NR_QUARTO, CD_FUNCIONARIO )
		values (curdate(), p_data_entrada,datediff(p_data_saida, p_data_entrada),'A', p_cd_cliente, p_nr_quarto, 1);
		return 'Reserva bem sucedida';	
	
	end if;	
end


/* 
d) criar uma rotina para adicionar um serviço a uma determinada hospedagem. Considerar os seguintes 
parâmetros: identificação da hospedagem e serviço. Atenção para a data 
de solicitação que deve ser a atual e o número de sequência (que deve seguir incremental 
apenas dentro do número da hospedagem, ou seja, este número é zerado para cada nova hospedagem) 
*/

-- criando uma function de agendamento de serviço - llguarnieri
create or replace function f_adicionar_servico_hospedagem( in p_cd_hospedagem int, 
														   in p_cd_servico int )
returns varchar(50)
begin 
	declare v_servico int;
	declare v_hospedagem int;

	select nvl(count(1), 0) into v_servico
	  from servico s 
	 where s.cd_servico = p_cd_servico; 
	
	select nvl(count(1), 0) into v_hospedagem
	  from hospedagem h 
	 where h.cd_hospedagem = p_cd_hospedagem;
	
	if (v_servico < 1) then
		return 'serviço ineistente';
	
	elseif (v_hospedagem < 1) then
		return 'hospedagem não encontrada';
	
	else 
		insert into hospedagem_servico (CD_HOSPEDAGEM, CD_SERVICO, NR_SEQUENCIA, DT_SOLICITACAO)
		values ( p_cd_hospedagem, 
				 p_cd_servico, 
				 ( select nvl(count(1), 0 ) 
				     from hospedagem_servico hs 
				    where hs.CD_HOSPEDAGEM = p_cd_hospedagem ),
				 curdate() );   

				return 'Serviço agendado com sucesso';
	end if;
end

select f_adicionar_servico_hospedagem(1,2) from dual


/*
e) criar uma rotina para mudar o status (coluna fl_situacao) para 'F' - 
finalizada. Esta rotina deverá receber como parâmetro o identificador da hospedagem.
*/

-- criando function para modificar status da hospedagem - llguarnieri
create or replace function f_fechar_hospedagem( in p_cd_hospedagem int)
returns varchar(50)

begin 
	declare v_cd_hosp int;

	select nvl( count(1) ,0) into v_cd_hosp
	  from hospedagem h 
	 where h.cd_hospedagem = p_cd_hospedagem; 
	
	if (v_cd_hosp < 1) then 
		return 'hospedagem inexistente';
	
	else 
		update hospedagem 
		   set fl_situacao = 'F'
		 where cd_hospedagem = p_cd_hospedagem;
			
		return concat('hospedagem ', p_cd_hospedagem, ' fechada com sucesso');
	end if;	
end

select f_fechar_hospedagem(1) from dual
