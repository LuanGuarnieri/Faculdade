package testes;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;

import negocio.Cliente;
import negocio.GerenciadoraClientes;
import negocio.IdadeNaoPermitidaException;

public class GerenciadoraClientesTest {

	List<Cliente> clientes;
	GerenciadoraClientes ger;
	
	//vai exxecutar a cada método rodado
		@Before
		public void criarListaClientes() {
			clientes = new ArrayList<>();
			Cliente c;
			
			c = new Cliente(1, "Luan Guarnieri", 21, "lguarnieri@furb.br", 100, true);
			clientes.add(c);
			c = new Cliente(2, "Maria Krutzsh", 20, "mkrutzsh@furb.br", 200, false);
			clientes.add(c);
			c = new Cliente(3, "Heitor Guarnieri", 15, "hguanieri@furb.br", 300, true);
			clientes.add(c);
			c = new Cliente(4, "Murilo Guarnieri", 11, "mguarnieri@furb.br", 400, true);
			clientes.add(c);
			c = new Cliente(5, "Priscila Guarnieri", 40, "pguarnieri@furb.br", 500, true);
			clientes.add(c);
			c = new Cliente(6, "Evaldo Guarnieri", 46, "eguarnieri@furb.br", 600, true);
			clientes.add(c);
			
			ger = new GerenciadoraClientes(clientes);
		}
		
		//Testa se a lista de criação é a mesma
		@Test
		public void pesquisaClienteTest() {
			assertEquals(ger.getClientesDoBanco(), clientes);
		}
		
		//Testa retorno lista vazia
		@Test
		public void pesquisaClienteTest2() {
			ger.limpa();
			assertEquals(clientes.size(), ger.getClientesDoBanco().size());
		}
		
		//Testa retornando um cliente e comparando um numero
		@Test
		public void pesquisaCliente1() {
			assertEquals(ger.pesquisaCliente(1).getNome().toLowerCase(), "luan guarnieri");
		}
		
		//Testa não achando o cliente e retornando null
		@Test
		public void pesquisaCliente2() {
			assertNull(ger.pesquisaCliente(10));
		}
		
		//Testa adicionando um novo cliente
		@Test
		public void adicionaCliente() {
			Cliente c = new Cliente(10, "Cleiton da Quebrada", 90, "cleiton@furb.br", 1001, true);
			
			ger.adicionaCliente(c);
			assertEquals(ger.pesquisaCliente(10).getIdContaCorrente(), 1001);
		}
		
		//Testa retirando um cliente
		@Test
		public void removeCliente1() {
			assertTrue(ger.removeCliente(1));	
		}
		
		//Testa retirando um cliente inexistente
		@Test
		public void removeCliente2() {
			assertFalse(ger.removeCliente(10));	
		}
		
		//Testa cliente ativo
		@Test
		public void clienteAtivo1() {
			assertTrue(ger.clienteAtivo(1));
		}
		
		//Testa cliente ativo
		@Test
		public void clienteAtivo2() {
			assertFalse(ger.clienteAtivo(2));
		}
		
		//Teste idade true
		@Test
		public void validaIdade1() throws IdadeNaoPermitidaException {
			assertTrue(ger.validaIdade(ger.pesquisaCliente(1).getIdade()));
		}
		
		//Teste idade true
		@Test
		public void validaIdade2() {
			char exp = 'A';
			
			try {
				ger.validaIdade(0);
			} catch (Exception e) {
				exp = 'E';
			}
			
			assertEquals('E', exp);
		}
		
		// Não poderia deixar inserir cliente null retornar uma exception
		@Test
		public void adicionaClienteNull() {
			char exp = 'A';
			
			try { 
				ger.adicionaCliente(null);
			} catch (Exception e) {
				exp = 'E';
			}
			
			assertEquals('E', exp);
		}

}
