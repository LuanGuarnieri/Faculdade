package testes;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;

import negocio.Cliente;
import negocio.ContaCorrente;
import negocio.GerenciadoraContas;

public class GerenciadoraContasTest {

	GerenciadoraContas gerContas;

	@Before
	public void CriaContaCorrentes() {
		
		List<Cliente> clientes = new ArrayList<>();
		List<ContaCorrente> contas = new ArrayList<>(); 
		ContaCorrente cont;
		Cliente c;
		
		c = new Cliente(1, "Luan Guarnieri", 21, "lguarnieri@furb.br", 100, true);
		clientes.add(c);
		c = new Cliente(2, "Maria Krutzsh", 20, "mkrutzsh@furb.br", 200, false);
		clientes.add(c);
		c = new Cliente(3, "Heitor Guarnieri", 15, "hguanieri@furb.br", 300, true);
		clientes.add(c);
		c = new Cliente(4, "Murilo Guarnieri", 11, "mguarnieri@furb.br", 400, true);
		clientes.add(c);
		c = new Cliente(5, "Priscila Guarnieri", 40, "pguarnieri@furb.br", 500, true);
		clientes.add(c);
		c = new Cliente(6, "Evaldo Guarnieri", 46, "eguarnieri@furb.br", 600, true);
		clientes.add(c);
		
		for(Cliente cli: clientes) {
			cont = new ContaCorrente(cli.getIdContaCorrente(), 1000, cli.isAtivo());
			contas.add(cont);
		}
		
		gerContas = new GerenciadoraContas(contas);
	}

	//Testa se retorna as contas
	@Test
	public void getContasDoBancoTest() {
		assertEquals(gerContas.getContasDoBanco().size(), 6);
	}
	
	//Testa se retorna uma conta em especifico
	@Test
	public void pesquisaConta1() {
		assertEquals(gerContas.pesquisaConta(100).getSaldo(), 1000,00);
	}

	//Testa se retorna null para conta inexistente
	@Test
	public void pesquisaConta2() {
		assertNull(gerContas.pesquisaConta(1000));
	}
	
	//Testa adicionando uma conta
	@Test
	public void adicionaConta() {
		gerContas.adicionaConta(new ContaCorrente(123, 11110, true));
		
		assertTrue(gerContas.pesquisaConta(123).isAtiva());
	}
	
	//Testa remoção de conta
	@Test
	public void removeConta1() {
		assertTrue(gerContas.removeConta(100));
	}
	
	//Testa remoção de conta inexistente
	@Test
	public void removeConta2() {
		assertFalse(gerContas.removeConta(1002));
	}
	
	//Testa conta ativa
	@Test
	public void contaAtiva1() {
		assertTrue(gerContas.contaAtiva(100));
	}
	
	//Testa conta inativa
	@Test
	public void contaAtiva2() {
		assertFalse(gerContas.contaAtiva(200));
	}
	
	//Testa conta inativa
	@Test
	public void contaAtiva3() {
		assertFalse(gerContas.contaAtiva(1000));
	}
	
	//Testa tranferencia com valores possitivos 
	@Test
	public void transfereValor1() {
		assertTrue(gerContas.transfereValor(100, 100, 200));
	}
	
	//Testa tranferencia com valores negativos
	@Test
	public void transfereValor2() {
		assertFalse(gerContas.transfereValor(100, -200, 200));
	}
	
	//Testa tranferencia com valores acima do limite
	@Test
	public void transfereValor3() {
		assertFalse(gerContas.transfereValor(100, 10000, 200));
	}
	
	//Testa adicionar uma conta null - deveria retornar exception
	@Test
	public void adicionaContaNull() {
		char exp = 'A';
		
		try {
			gerContas.adicionaConta(null);
		} catch (Exception e) {
			exp = 'E';
		}
		
		assertEquals('E', exp);
	}

}
